<?php
/* Just an example of route extension */
$route = function ($handler) {
    die('hello world!');
};
