<?php

use PHPMailer\PHPMailer\PHPMailer;

class Mailer extends PHPMailer
{
    public $DbgOut = '';
    protected function edebug($str)
    {
        $this->DbgOut .= $str;
    }
}
